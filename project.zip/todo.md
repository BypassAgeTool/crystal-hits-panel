# Crystal Hits Panel - TODO

## Banco de Dados e API
- [x] Criar schema de banco de dados para hits, eventos e contas
- [x] Implementar API endpoints para registrar hits
- [x] Criar API para estatísticas e agregações
- [x] Implementar sistema de autenticação via API key para extensão

## Dashboard Principal
- [x] Criar layout do dashboard com sidebar
- [x] Implementar cards de estatísticas (total hits, cliques, contas)
- [x] Adicionar gráficos de hits ao longo do tempo
- [x] Implementar modo anônimo para ocultar dados sensíveis

## Sistema de Rastreamento
- [x] Criar tabela de histórico de hits com filtros
- [x] Implementar paginação para histórico
- [x] Adicionar filtros por data e tipo de evento
- [x] Sistema de notificações em tempo real

## Página de Estatísticas
- [x] Criar página dedicada para estatísticas detalhadas
- [x] Implementar gráficos avançados (linha, barra, pizza)
- [x] Adicionar métricas de crescimento e comparações

## Integração com Extensão
- [x] Modificar extensão para enviar hits ao painel
- [x] Implementar sistema de API key na extensão
- [x] Testar integração completa

## Finalização
- [x] Aplicar estilo visual elegante e profissional
- [x] Testar todas funcionalidades
- [x] Criar checkpoint final

## Configuração de Webhook
- [x] Remover sistema de API Keys
- [x] Criar schema de configuração com webhook
- [x] Implementar página de configuração de webhook
- [x] Gerar extensão automaticamente com webhook configurado
- [x] Testar novo fluxo
