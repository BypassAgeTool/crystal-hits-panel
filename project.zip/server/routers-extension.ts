import { protectedProcedure, router } from "./_core/trpc";
import { generateExtension } from "./extension-generator";
import * as db from "./db";

export const extensionRouter = router({
  download: protectedProcedure.mutation(async ({ ctx }) => {
    // Obter a configuração do usuário
    const userConfig = await db.getConfigByUserId(ctx.user.id);
    
    if (!userConfig || !userConfig.webhookUrl) {
      throw new Error("Webhook não configurado. Configure em Configurações primeiro.");
    }

    // Obter a URL do painel
    const panelUrl = userConfig.panelUrl || process.env.VITE_FRONTEND_FORGE_API_URL || "https://seu-painel.manus.space";
    const webhookUrl = userConfig.webhookUrl;

    // Gerar a extensão
    const extensionBuffer = await generateExtension(webhookUrl, panelUrl, {
      title: userConfig.extensionTitle || undefined,
      description: userConfig.extensionDescription || undefined,
      background: userConfig.extensionBackground || undefined,
      primaryColor: userConfig.extensionPrimaryColor || undefined,
    });

    // Retornar como base64 para download
    return {
      data: extensionBuffer.toString("base64"),
      filename: `crystal-extension-${Date.now()}.zip`,
    };
  }),
});
