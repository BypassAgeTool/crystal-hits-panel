import type { Express, Request, Response } from "express";
import axios from "axios";
import * as db from "../db";
import { sdk } from "./sdk";
import { getSessionCookieOptions } from "./cookies";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Discord OAuth2 Configuration
const DISCORD_CLIENT_ID = "1457091242189131828";
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || "99cnjlSBj6QJ5kv23GvlgFmE2ES1kI6B";
const DISCORD_REDIRECT_URI = process.env.DISCORD_REDIRECT_URI || "http://localhost:3000/api/discord/callback";

interface DiscordTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token: string;
  scope: string;
}

interface DiscordUser {
  id: string;
  username: string;
  discriminator: string;
  avatar: string | null;
  email?: string;
  verified?: boolean;
}

/**
 * Log Discord authentication events
 */
function logDiscordAuth(event: string, data: any = {}) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    event,
    applicationId: DISCORD_CLIENT_ID,
    ...data
  };
  
  // Log to file or database
  console.log('[DISCORD_AUTH]', JSON.stringify(logEntry));
}

/**
 * Exchange authorization code for access token
 */
async function exchangeCodeForToken(code: string): Promise<DiscordTokenResponse> {
  logDiscordAuth('token_exchange_start', { code: code.substring(0, 10) + '...' });
  
  try {
    const response = await axios.post<DiscordTokenResponse>(
      'https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: DISCORD_REDIRECT_URI,
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );
    
    logDiscordAuth('token_exchange_success', {
      tokenType: response.data.token_type,
      expiresIn: response.data.expires_in,
      scope: response.data.scope
    });
    
    return response.data;
  } catch (error: any) {
    logDiscordAuth('token_exchange_error', {
      error: error.message,
      status: error.response?.status,
      data: error.response?.data
    });
    throw error;
  }
}

/**
 * Get Discord user information
 */
async function getDiscordUser(accessToken: string): Promise<DiscordUser> {
  logDiscordAuth('user_info_fetch_start');
  
  try {
    const response = await axios.get<DiscordUser>(
      'https://discord.com/api/users/@me',
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );
    
    logDiscordAuth('user_info_fetch_success', {
      userId: response.data.id,
      username: response.data.username,
      verified: response.data.verified
    });
    
    return response.data;
  } catch (error: any) {
    logDiscordAuth('user_info_fetch_error', {
      error: error.message,
      status: error.response?.status
    });
    throw error;
  }
}

/**
 * Register Discord OAuth routes
 */
export function registerDiscordAuthRoutes(app: Express) {
  // Discord OAuth login endpoint
  app.get("/api/discord/login", (req: Request, res: Response) => {
    logDiscordAuth('login_initiated', {
      ip: req.ip,
      userAgent: req.headers['user-agent']
    });
    
    const authUrl = `https://discord.com/api/oauth2/authorize?client_id=${DISCORD_CLIENT_ID}&redirect_uri=${encodeURIComponent(DISCORD_REDIRECT_URI)}&response_type=code&scope=identify%20email`;
    
    res.redirect(authUrl);
  });

  // Discord OAuth callback endpoint
  app.get("/api/discord/callback", async (req: Request, res: Response) => {
    const code = req.query.code as string | undefined;
    const error = req.query.error as string | undefined;

    if (error) {
      logDiscordAuth('callback_error', { error });
      res.status(400).json({ error: `Discord OAuth error: ${error}` });
      return;
    }

    if (!code) {
      logDiscordAuth('callback_missing_code');
      res.status(400).json({ error: "Authorization code is required" });
      return;
    }

    try {
      logDiscordAuth('callback_received', {
        code: code.substring(0, 10) + '...',
        ip: req.ip
      });
      
      // Exchange code for token
      const tokenData = await exchangeCodeForToken(code);
      
      // Get user information
      const discordUser = await getDiscordUser(tokenData.access_token);
      
      // Store or update user in database
      const openId = `discord:${discordUser.id}`;
      await db.upsertUser({
        openId,
        name: `${discordUser.username}#${discordUser.discriminator}`,
        email: discordUser.email || null,
        loginMethod: "discord",
        lastSignedIn: new Date(),
      });
      
      // Create session token
      const sessionToken = await sdk.createSessionToken(openId, {
        name: `${discordUser.username}#${discordUser.discriminator}`,
        expiresInMs: ONE_YEAR_MS,
      });
      
      // Set session cookie
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      
      logDiscordAuth('user_authenticated', {
        discordId: discordUser.id,
        username: discordUser.username,
        sessionCreated: true
      });
      
      // Redirect to dashboard
      res.redirect("/");
    } catch (error: any) {
      logDiscordAuth('callback_exception', {
        error: error.message,
        stack: error.stack
      });
      res.status(500).json({ error: "Discord authentication failed" });
    }
  });

  // Discord user info endpoint (for authenticated users)
  app.get("/api/discord/me", async (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      logDiscordAuth('me_unauthorized', { ip: req.ip });
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const accessToken = authHeader.substring(7);
    
    try {
      const discordUser = await getDiscordUser(accessToken);
      
      logDiscordAuth('me_success', {
        userId: discordUser.id,
        username: discordUser.username
      });
      
      res.json(discordUser);
    } catch (error: any) {
      logDiscordAuth('me_error', {
        error: error.message
      });
      res.status(401).json({ error: "Invalid or expired token" });
    }
  });
}
