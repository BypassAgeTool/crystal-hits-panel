CREATE TABLE `config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`webhookUrl` text NOT NULL,
	`panelUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `config_id` PRIMARY KEY(`id`),
	CONSTRAINT `config_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
DROP TABLE `api_keys`;--> statement-breakpoint
ALTER TABLE `captured_accounts` ADD `userId` int;--> statement-breakpoint
ALTER TABLE `hits` ADD `userId` int;--> statement-breakpoint
ALTER TABLE `hits` DROP COLUMN `apiKeyId`;