import { useQuery } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, Crown, Star, TrendingUp, Skull } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";

export default function TopGlobal() {
  const { data: topAccounts, isLoading } = trpc.accounts.getTopGlobal.useQuery();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center gap-3">
                <Trophy className="h-10 w-10 text-yellow-500" />
                Top Global Crystal
              </h1>
              <p className="text-muted-foreground mt-2">
                As contas mais valiosas capturadas por todos os usuários do sistema.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-card/50 border-primary/20 backdrop-blur">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Crown className="h-4 w-4 text-yellow-500" />
                  Maior Robux
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {topAccounts?.[0]?.robux?.toLocaleString() || 0} R$
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card/50 border-primary/20 backdrop-blur">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-500" />
                  Maior Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {topAccounts?.[0]?.summary?.toLocaleString() || 0}
                </div>
              </CardContent>
            </Card>
            <Card className="bg-card/50 border-primary/20 backdrop-blur">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Skull className="h-4 w-4 text-purple-500" />
                  Itens Raros
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {topAccounts?.filter(a => a.hasKorblox || a.hasHeadless).length || 0} Detectados
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-primary/20 bg-card/30 backdrop-blur">
            <CardHeader>
              <CardTitle>Ranking de Contas</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Posição</TableHead>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Robux</TableHead>
                    <TableHead>RAP / Summary</TableHead>
                    <TableHead>Itens Raros</TableHead>
                    <TableHead className="text-right">Capturada em</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-10">Carregando ranking...</TableCell>
                    </TableRow>
                  ) : topAccounts?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-10">Nenhuma conta capturada ainda.</TableCell>
                    </TableRow>
                  ) : (
                    topAccounts?.map((account, index) => {
                      const metadata = account.metadata ? JSON.parse(account.metadata) : {};
                      return (
                        <TableRow key={account.id} className="group hover:bg-primary/5 transition-colors">
                          <TableCell className="font-bold">
                            {index === 0 ? <Crown className="h-6 w-6 text-yellow-500" /> : 
                             index === 1 ? <Star className="h-5 w-5 text-gray-400" /> :
                             index === 2 ? <Star className="h-5 w-5 text-amber-600" /> :
                             `#${index + 1}`}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="h-10 w-10 border border-primary/20">
                                <AvatarImage src={metadata.thumbnailUrl} />
                                <AvatarFallback>{metadata.username?.[0] || '?'}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{metadata.displayName || 'Desconhecido'}</div>
                                <div className="text-xs text-muted-foreground">@{metadata.username || 'n/a'}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                              {account.robux?.toLocaleString()} R$
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm font-medium">{account.summary?.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">RAP: {account.rap?.toLocaleString()}</div>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {account.hasKorblox && <Badge className="bg-purple-600">KORBLOX</Badge>}
                              {account.hasHeadless && <Badge className="bg-slate-700">HEADLESS</Badge>}
                              {!account.hasKorblox && !account.hasHeadless && <span className="text-muted-foreground text-xs">-</span>}
                            </div>
                          </TableCell>
                          <TableCell className="text-right text-xs text-muted-foreground">
                            {new Date(account.capturedAt).toLocaleDateString('pt-BR')}
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
