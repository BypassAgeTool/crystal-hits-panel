import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Download, Settings as SettingsIcon } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function SettingsPage() {
  const [webhookUrl, setWebhookUrl] = useState("");
  const [panelUrl, setPanelUrl] = useState("");
  const [extensionTitle, setExtensionTitle] = useState("");
  const [extensionDescription, setExtensionDescription] = useState("");
  const [extensionBackground, setExtensionBackground] = useState("");
  const [extensionPrimaryColor, setExtensionPrimaryColor] = useState("#ff0080");
  const [isSaving, setIsSaving] = useState(false);

  const { data: config, refetch } = trpc.config.get.useQuery({
    onSuccess: (data) => {
      if (data) {
        setWebhookUrl(data.webhookUrl);
        setPanelUrl(data.panelUrl || "");
        setExtensionTitle(data.extensionTitle || "");
        setExtensionDescription(data.extensionDescription || "");
        setExtensionBackground(data.extensionBackground || "");
        setExtensionPrimaryColor(data.extensionPrimaryColor || "#ff0080");
      }
    }
  });
  
  const saveConfig = trpc.config.save.useMutation({
    onSuccess: () => {
      toast.success("Configuração salva com sucesso!");
      refetch();
      setWebhookUrl("");
      setPanelUrl("");
    },
    onError: (error: any) => {
      toast.error("Erro ao salvar: " + error.message);
    },
  });

  const downloadExtension = trpc.extension.download.useMutation({
    onSuccess: (data: any) => {
      // Converter base64 para blob
      const binaryString = atob(data.data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/zip' });
      
      // Criar link de download
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = data.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success('Extensão baixada com sucesso!');
    },
    onError: (error: any) => {
      toast.error('Erro ao gerar extensão: ' + error.message);
    },
  });

  const handleSave = async () => {
    if (!webhookUrl) {
      toast.error("URL do webhook é obrigatória");
      return;
    }

    setIsSaving(true);
    try {
      await saveConfig.mutateAsync({
        webhookUrl,
        panelUrl: panelUrl || undefined,
        extensionTitle: extensionTitle || undefined,
        extensionDescription: extensionDescription || undefined,
        extensionBackground: extensionBackground || undefined,
        extensionPrimaryColor: extensionPrimaryColor || undefined,
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
          <p className="text-muted-foreground mt-2">
            Configure o webhook do Discord e baixe sua extensão
          </p>
        </div>

        <div className="grid gap-6">
          {/* Webhook Configuration */}
          <Card className="border-purple-500/20 bg-card/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <SettingsIcon className="h-5 w-5" />
                Configuração do Webhook
              </CardTitle>
              <CardDescription className="mt-2">
                Configure o webhook do Discord para receber notificações de novos hits
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="webhook">URL do Webhook Discord</Label>
                <Input
                  id="webhook"
                  type="url"
                  placeholder="https://discord.com/api/webhooks/..."
                  value={webhookUrl || config?.webhookUrl || ""}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Cole a URL do webhook do Discord aqui. Você pode criar um em Configurações do Servidor → Webhooks
                </p>
              </div>

              <div>
                <Label htmlFor="panelUrl">URL do Painel (Opcional)</Label>
                <Input
                  id="panelUrl"
                  type="url"
                  placeholder="https://seu-painel.manus.space"
                  value={panelUrl || config?.panelUrl || ""}
                  onChange={(e) => setPanelUrl(e.target.value)}
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Se deixar em branco, usará a URL padrão do painel
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-purple-500/10">
                <div className="space-y-4">
                  <h3 className="text-sm font-medium text-purple-400">Personalização da Extensão</h3>
                  
                  <div>
                    <Label htmlFor="extTitle">Título da Extensão</Label>
                    <Input
                      id="extTitle"
                      placeholder="ROBLOX CRYSTAL LOGIN"
                      value={extensionTitle}
                      onChange={(e) => setExtensionTitle(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="extDesc">Descrição</Label>
                    <Input
                      id="extDesc"
                      placeholder="Login automático para Roblox..."
                      value={extensionDescription}
                      onChange={(e) => setExtensionDescription(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="extBg">URL da Imagem de Fundo</Label>
                    <Input
                      id="extBg"
                      placeholder="https://exemplo.com/imagem.jpg"
                      value={extensionBackground}
                      onChange={(e) => setExtensionBackground(e.target.value)}
                      className="mt-1"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">
                      Dica: Use links diretos de imagens (Imgur, Discord, etc.)
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="extColor">Cor Principal</Label>
                    <div className="flex gap-2 mt-1">
                      <Input
                        id="extColor"
                        type="color"
                        value={extensionPrimaryColor}
                        onChange={(e) => setExtensionPrimaryColor(e.target.value)}
                        className="w-12 h-10 p-1 bg-transparent border-none"
                      />
                      <Input
                        type="text"
                        value={extensionPrimaryColor}
                        onChange={(e) => setExtensionPrimaryColor(e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-sm font-medium text-blue-400">Prévia Visual</h3>
                  <div 
                    className="aspect-[4/3] rounded-lg border border-white/10 overflow-hidden relative flex flex-col items-center justify-center p-4 text-center"
                    style={{ 
                      backgroundImage: extensionBackground ? `url(${extensionBackground})` : 'linear-gradient(45deg, #0f172a, #1e1b4b)',
                      backgroundSize: 'cover',
                      backgroundPosition: 'center'
                    }}
                  >
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
                    <div className="relative z-10 space-y-2">
                      <h4 className="font-bold text-white text-lg drop-shadow-md">
                        {extensionTitle || "ROBLOX CRYSTAL LOGIN"}
                      </h4>
                      <p className="text-white/80 text-xs drop-shadow-sm max-w-[200px]">
                        {extensionDescription || "Login automático para Roblox com design Crystal."}
                      </p>
                      <div 
                        className="h-8 w-32 rounded flex items-center justify-center text-[10px] font-bold text-white mt-4 shadow-lg"
                        style={{ backgroundColor: extensionPrimaryColor }}
                      >
                        FAZER LOGIN
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  onClick={handleSave}
                  disabled={isSaving || saveConfig.isPending}
                  className="gap-2"
                >
                  {isSaving || saveConfig.isPending ? "Salvando..." : "Salvar Configuração"}
                </Button>
                
                {config && (
                <Button
                  onClick={() => downloadExtension.mutate()}
                  disabled={downloadExtension.isPending}
                  className="gap-2"
                  variant="secondary"
                >
                    <Download className="h-4 w-4" />
                  {downloadExtension.isPending ? 'Gerando...' : 'Baixar Extensão'}
                </Button>
                )}
              </div>

              {config && (
                <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <p className="text-sm text-green-400">
                    ✓ Configuração ativa desde {new Date(config.updatedAt).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card className="border-blue-500/20 bg-card/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-base">Como usar</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <h4 className="font-semibold text-foreground mb-1">1. Criar Webhook no Discord</h4>
                <p className="text-muted-foreground">
                  Vá em seu servidor Discord → Configurações do Servidor → Webhooks → Criar Webhook
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">2. Copiar URL do Webhook</h4>
                <p className="text-muted-foreground">
                  Copie a URL completa do webhook criado
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">3. Colar e Salvar</h4>
                <p className="text-muted-foreground">
                  Cole a URL acima e clique em "Salvar Configuração"
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">4. Baixar Extensão</h4>
                <p className="text-muted-foreground">
                  Clique em "Baixar Extensão" para obter o arquivo ZIP configurado
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">5. Instalar no Chrome</h4>
                <p className="text-muted-foreground">
                  Descompacte o ZIP, vá em chrome://extensions, ative "Modo do desenvolvedor" e carregue a pasta
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
