# ⚡ Deploy Rápido - 3 Passos

## 🎯 Opção Mais Fácil: RENDER.COM

### Passo 1: Criar Repositório GitHub
1. Acesse: https://github.com/new
2. Nome do repositório: `crystal-hits-panel`
3. Público ✅
4. Clique em "Create repository"

### Passo 2: Fazer Upload do Código
Você tem 2 opções:

#### Opção A: Via Terminal (se tiver Git configurado)
```bash
cd /home/ubuntu
git remote add origin https://github.com/SEU_USUARIO/crystal-hits-panel.git
git branch -M main
git push -u origin main
```

#### Opção B: Via Interface do GitHub (mais fácil)
1. Baixe o arquivo: `crystal-hits-panel-deploy.tar.gz`
2. Extraia os arquivos
3. No GitHub, clique em "uploading an existing file"
4. Arraste todos os arquivos
5. Commit!

### Passo 3: Deploy no Render
1. Acesse: https://render.com
2. Clique em "Get Started for Free"
3. Login com GitHub
4. Clique em "New +" → "Blueprint"
5. Conecte o repositório `crystal-hits-panel`
6. Render detecta o `render.yaml` automaticamente
7. Clique em "Apply"
8. Aguarde 5-10 minutos
9. **PRONTO!** Seu link: `https://crystal-hits-panel.onrender.com`

---

## 🎉 Resultado Final

Você terá:
- ✅ Link personalizado: `https://crystal-hits-panel.onrender.com`
- ✅ SSL/HTTPS automático
- ✅ Banco de dados MySQL grátis
- ✅ Deploy automático a cada push no GitHub
- ✅ 100% gratuito, sem cartão de crédito

---

## 🔧 Configuração Adicional

Após o deploy, você pode:
1. **Adicionar domínio próprio** (se tiver)
   - Settings → Custom Domain
   - Adicionar CNAME no seu DNS

2. **Configurar Discord OAuth**
   - Atualizar `DISCORD_REDIRECT_URI` com seu domínio
   - https://discord.com/developers/applications

3. **Personalizar**
   - Acessar o painel
   - Ir em Configurações
   - Customizar cores, logo, etc.

---

## 📞 Precisa de Ajuda?

Se tiver dúvidas em qualquer passo, me avise! 🚀
