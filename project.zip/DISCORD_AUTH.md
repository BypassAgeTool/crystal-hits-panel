# Autenticação Discord OAuth2

## Configuração

Este painel agora inclui autenticação Discord OAuth2 com logging completo.

### Credenciais Configuradas

- **Application ID**: `1457091242189131828`
- **Client Secret**: `t-Bh4nAJs4G8Z2GBC9JoDmjqijn8xMn2`

### Endpoints Disponíveis

#### 1. Iniciar Login Discord
```
GET /api/discord/login
```
Redireciona o usuário para a página de autorização do Discord.

#### 2. Callback OAuth
```
GET /api/discord/callback?code=<authorization_code>
```
Processa o código de autorização e autentica o usuário.

**Resposta de Sucesso:**
```json
{
  "success": true,
  "user": {
    "id": "123456789",
    "username": "usuario",
    "email": "usuario@example.com"
  }
}
```

#### 3. Informações do Usuário
```
GET /api/discord/me
Authorization: Bearer <access_token>
```
Retorna informações do usuário autenticado.

### Configuração de Variável de Ambiente

Adicione ao arquivo `.env` (ou configure no ambiente):

```env
DISCORD_REDIRECT_URI=http://localhost:3000/api/discord/callback
```

Para produção, altere para sua URL pública:
```env
DISCORD_REDIRECT_URI=https://seu-dominio.com/api/discord/callback
```

### Logs de Autenticação

Todos os eventos de autenticação são registrados com o prefixo `[DISCORD_AUTH]` e incluem:

- `login_initiated` - Quando um usuário inicia o processo de login
- `callback_received` - Quando o callback é recebido
- `token_exchange_start` - Início da troca do código por token
- `token_exchange_success` - Token obtido com sucesso
- `token_exchange_error` - Erro ao obter token
- `user_info_fetch_start` - Início da busca de informações do usuário
- `user_info_fetch_success` - Informações obtidas com sucesso
- `user_info_fetch_error` - Erro ao buscar informações
- `user_authenticated` - Usuário autenticado com sucesso
- `callback_error` - Erro no callback
- `callback_exception` - Exceção durante o callback
- `me_success` - Informações do usuário obtidas via /me
- `me_error` - Erro ao obter informações via /me
- `me_unauthorized` - Tentativa não autorizada de acessar /me

### Formato do Log

```json
{
  "timestamp": "2026-01-03T14:40:00.000Z",
  "event": "user_authenticated",
  "applicationId": "1457091242189131828",
  "discordId": "123456789",
  "username": "usuario"
}
```

### Integração com Frontend

Para integrar no frontend, adicione um botão de login:

```tsx
<Button onClick={() => window.location.href = '/api/discord/login'}>
  Login com Discord
</Button>
```

### Configuração no Discord Developer Portal

1. Acesse: https://discord.com/developers/applications/1457091242189131828
2. Vá em **OAuth2** → **General**
3. Adicione a Redirect URI:
   - Desenvolvimento: `http://localhost:3000/api/discord/callback`
   - Produção: `https://seu-dominio.com/api/discord/callback`
4. Em **OAuth2** → **URL Generator**, selecione os scopes:
   - `identify` - Obter informações básicas do usuário
   - `email` - Obter email do usuário

### Segurança

- O Client Secret está configurado no código para facilitar o desenvolvimento
- **IMPORTANTE**: Para produção, mova as credenciais para variáveis de ambiente
- Nunca compartilhe o Client Secret publicamente
- Use HTTPS em produção para proteger os tokens

### Modificações Realizadas

1. ✅ Removidos todos os `console.log` existentes
2. ✅ Criado sistema de autenticação Discord OAuth2
3. ✅ Implementado logging estruturado para todos os eventos de autenticação
4. ✅ Integrado com o sistema de usuários existente
5. ✅ Adicionados endpoints RESTful para autenticação
