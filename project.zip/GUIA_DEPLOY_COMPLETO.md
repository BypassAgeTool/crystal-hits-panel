# 🚀 Guia Completo de Deploy - Crystal Hits Panel

## 📦 Seu Projeto Está Pronto!

Preparei tudo para você fazer o deploy e ter um link personalizado. Aqui estão as **3 melhores opções gratuitas**:

---

## ✅ **OPÇÃO 1: RENDER.COM (Mais Recomendado)**

### Por que escolher Render?
- ✅ **Totalmente gratuito** (750 horas/mês = 24/7)
- ✅ **Banco de dados MySQL/PostgreSQL grátis**
- ✅ **SSL automático**
- ✅ **Domínio personalizado:** `seuprojeto.onrender.com`
- ✅ **Deploy automático do GitHub**
- ✅ **Sem cartão de crédito necessário**

### Como fazer deploy:

#### 1. Criar conta no Render
- Acesse: https://render.com
- Clique em "Get Started for Free"
- Faça login com GitHub

#### 2. Criar banco de dados MySQL
- No dashboard, clique em "New +"
- Escolha "PostgreSQL" (grátis) ou use TiDB Cloud para MySQL
- Copie a `DATABASE_URL`

#### 3. Deploy da aplicação
- Clique em "New +" → "Web Service"
- Conecte seu repositório GitHub
- Configure:
  - **Build Command:** `pnpm install && pnpm build`
  - **Start Command:** `pnpm start`
  - **Environment:** Node
  
#### 4. Adicionar variáveis de ambiente
```
DATABASE_URL=sua_url_do_banco
JWT_SECRET=crystal-hits-super-secret-key-production-2026
DISCORD_CLIENT_SECRET=99cnjlSBj6QJ5kv23GvlgFmE2ES1kI6B
NODE_ENV=production
```

#### 5. Deploy!
- Clique em "Create Web Service"
- Aguarde o build (5-10 minutos)
- Seu link: `https://crystal-hits-panel.onrender.com`

---

## ✅ **OPÇÃO 2: RAILWAY.APP**

### Por que escolher Railway?
- ✅ **$5 de crédito grátis/mês**
- ✅ **Banco de dados MySQL incluído**
- ✅ **SSL automático**
- ✅ **Domínio:** `seuprojeto.up.railway.app`
- ✅ **Deploy mais rápido**

### Como fazer deploy:

#### 1. Criar conta
- Acesse: https://railway.app
- Faça login com GitHub

#### 2. Novo projeto
- Clique em "New Project"
- Escolha "Deploy from GitHub repo"
- Selecione seu repositório

#### 3. Adicionar MySQL
- No projeto, clique em "+ New"
- Escolha "Database" → "MySQL"
- Railway conecta automaticamente

#### 4. Configurar variáveis
- Vá em Settings do serviço
- Adicione as variáveis de ambiente
- Railway já fornece `DATABASE_URL` automaticamente

#### 5. Gerar domínio
- Em Settings → Networking
- Clique em "Generate Domain"
- Pronto! `https://seuprojeto.up.railway.app`

---

## ✅ **OPÇÃO 3: FLY.IO**

### Por que escolher Fly.io?
- ✅ **Gratuito para pequenos projetos**
- ✅ **Deploy via CLI**
- ✅ **Rápido e global**
- ✅ **Domínio:** `seuprojeto.fly.dev`

### Como fazer deploy:

#### 1. Instalar Fly CLI
```bash
curl -L https://fly.io/install.sh | sh
```

#### 2. Login
```bash
fly auth login
```

#### 3. Criar app
```bash
cd /home/ubuntu
fly launch
```

#### 4. Configurar banco
```bash
fly mysql create
fly secrets set DATABASE_URL="sua_url"
```

#### 5. Deploy
```bash
fly deploy
```

---

## 🎯 **MINHA RECOMENDAÇÃO**

### Para você, recomendo **RENDER.COM** porque:
1. ✅ Não precisa de cartão de crédito
2. ✅ Interface mais simples
3. ✅ Banco de dados grátis incluído
4. ✅ Deploy automático do GitHub
5. ✅ SSL e domínio personalizado grátis

---

## 📋 **ARQUIVOS PREPARADOS**

Já criei tudo que você precisa:
- ✅ `railway.json` - Configuração para Railway
- ✅ `.railwayignore` - Arquivos ignorados
- ✅ `.gitignore` - Git configurado
- ✅ Repositório Git inicializado
- ✅ Código commitado

---

## 🔗 **PRÓXIMOS PASSOS**

### Se escolher Render ou Railway:

1. **Criar repositório no GitHub:**
   - Acesse: https://github.com/new
   - Nome: `crystal-hits-panel`
   - Público
   - Criar repositório

2. **Fazer push do código:**
   ```bash
   cd /home/ubuntu
   git remote add origin https://github.com/SEU_USUARIO/crystal-hits-panel.git
   git branch -M main
   git push -u origin main
   ```

3. **Conectar no Render/Railway:**
   - Selecionar o repositório
   - Configurar variáveis
   - Deploy!

---

## 🆘 **PRECISA DE AJUDA?**

Posso te ajudar com:
1. ✅ Criar o repositório GitHub (você precisa me dar acesso)
2. ✅ Configurar as variáveis de ambiente
3. ✅ Fazer o deploy passo a passo
4. ✅ Configurar domínio personalizado próprio

**Me diga qual opção você prefere e eu te ajudo!** 🚀
