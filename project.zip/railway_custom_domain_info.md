# Como Configurar Domínio Personalizado no Railway

## 📋 Resumo

Para ter um domínio personalizado como `crystalhits.railway.app` ou seu próprio domínio (ex: `seusite.com`), você precisa:

### Opção 1: Domínio Railway Gratuito
- Deploy no Railway
- Gerar domínio automático (ex: `seuprojeto.up.railway.app`)
- **Gratuito** mas com nome gerado automaticamente

### Opção 2: Domínio Personalizado Próprio
- Comprar um domínio (Namecheap, Cloudflare, etc)
- Fazer deploy no Railway
- Configurar CNAME no seu provedor DNS
- Apontar para o Railway

## 🚀 Passos para Deploy no Railway

1. **Criar conta no Railway** (railway.app)
2. **Conectar repositório GitHub** ou fazer upload
3. **Configurar variáveis de ambiente**
4. **Deploy automático**
5. **Gerar domínio** ou adicionar domínio personalizado

## 💰 Custos

- **Railway:** Plano gratuito com $5 de crédito/mês
- **Domínio personalizado:** ~$10-15/ano (se quiser seu próprio)
- **Banco de dados:** Incluído no Railway

## ⚙️ Configuração de Domínio Personalizado

### No Railway:
1. Vá em Settings do seu serviço
2. Clique em "+ Custom Domain"
3. Digite seu domínio (ex: `crystalhits.com`)
4. Railway fornecerá um CNAME (ex: `g05ns7.up.railway.app`)

### No seu provedor DNS (Cloudflare, Namecheap, etc):
1. Crie um registro CNAME
2. Nome: `@` (para domínio raiz) ou `www` (para subdomínio)
3. Valor: O CNAME fornecido pelo Railway
4. Aguarde propagação (até 72h, geralmente minutos)

## 🎯 Limitações

- **Trial Plan:** 1 domínio personalizado
- **Hobby Plan:** 2 domínios personalizados por serviço
- **Pro Plan:** 20 domínios por serviço

## 📝 Observações Importantes

- Domínios Freenom não são suportados
- SSL é emitido automaticamente pelo Railway
- Suporta domínios wildcard (ex: `*.seusite.com`)
