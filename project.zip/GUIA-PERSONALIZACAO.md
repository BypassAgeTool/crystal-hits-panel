# 🎨 Guia de Personalização da Extensão

Agora você pode deixar a sua extensão com a cara que quiser! Implementei uma nova seção na página de **Configurações** que permite mudar tudo visualmente.

## 🚀 O que você pode personalizar:

1.  **🖼️ Imagem de Fundo:** Coloque qualquer imagem (URL) no fundo da extensão.
2.  **✍️ Título Personalizado:** Mude o nome principal da extensão (ex: "ROBLOX LOGIN", "CRYSTAL FREE").
3.  **📝 Descrição:** Altere o texto de ajuda que aparece abaixo do título.
4.  **🌈 Cor Principal:** Escolha a cor dos botões, bordas e efeitos de brilho usando um seletor de cores.

## 👁️ Prévia em Tempo Real

Na página de configurações, adicionei uma **Prévia Visual**. Conforme você digita ou muda a cor, você vê exatamente como a extensão vai ficar antes mesmo de baixar!

## 🛠️ Como usar:

1.  Vá na aba **Configurações** no seu painel.
2.  Preencha os campos na seção **Personalização da Extensão**.
3.  Veja como ficou na **Prévia Visual** ao lado.
4.  Clique em **Salvar Configuração**.
5.  Clique em **Baixar Extensão**.
6.  A extensão baixada já virá com todas as suas escolhas aplicadas!

## 💡 Dicas para Imagens de Fundo:

- Use links diretos de imagens (que terminam em `.jpg`, `.png` ou `.gif`).
- Você pode usar o Discord para hospedar suas imagens: mande a foto em um canal, clique com o botão direito e selecione "Copiar link da imagem".
- Imagens escuras ou com brilho combinam melhor com o estilo "Crystal".

## ✅ Alterações Técnicas Realizadas:

- **Banco de Dados:** Adicionados campos `extensionTitle`, `extensionDescription`, `extensionBackground` e `extensionPrimaryColor` na tabela `config`.
- **Frontend:** Nova interface em `Settings.tsx` com inputs e preview.
- **Backend:** Rotas tRPC atualizadas para salvar e recuperar esses dados.
- **Gerador:** O arquivo `extension-generator.ts` agora injeta dinamicamente o CSS e HTML baseado nas suas configurações.

---

**Aproveite sua nova extensão personalizada!** 💎
